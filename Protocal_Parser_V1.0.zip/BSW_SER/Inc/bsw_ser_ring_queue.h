#ifndef __BSW_SER_RING_QUEUE_H
#define __BSW_SER_RING_QUEUE_H
#include "stm32f4xx_hal.h"
#include "usart.h"

#define UART_RX_BUFF_LEN    (512)
#define RING_BUFF_LEN       (2048)

typedef struct ringQueue
{
	uint8_t ring_buff[RING_BUFF_LEN];  //< ���λ�����
	uint16_t ring_head;                //< ��ָ��
	uint16_t ring_tail;                //< дָ��
	volatile uint16_t ring_data_size;  //< ��ǰ������������
}RingQueue;

extern uint8_t uart_rx_dma_buff[UART_RX_BUFF_LEN];  // DMA Ŀ�껺����
extern RingQueue g_queue;
extern uint16_t last_dma_rx_pos;

void Init_RingQueue(RingQueue *queue);
void ring_write(RingQueue *queue, uint8_t data);
uint8_t ring_read(RingQueue *queue);
uint16_t getRingSize(RingQueue *queue);
void copy_to_ring(RingQueue *queue, uint8_t *src_buff, uint16_t len);
void uart1_idle_isr(void);
void dmarx_half_done_isr(void);
void dmarx_done_isr(void);

#endif
