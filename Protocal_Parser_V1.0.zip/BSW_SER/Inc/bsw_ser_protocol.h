#ifndef __BSW_SER_PROTOCOL_H
#define __BSW_SER_PROTOCOL_H
#include "stm32f4xx_hal.h"

#define BSW_FRAME_HEAD1       0xAA
#define BSW_FRAME_HEAD2       0x55

#define BSW_FRAME_TAIL1       0x55
#define BSW_FRAME_TAIL2       0xAA

#define BSW_FRAME_LEN         0x03
#define BSW_FRAME_CRC         0x5A

#define BSW_FRAME_SIZE        9

#define BSW_MOTOR_MIN         0x00
#define BSW_MOTOR_MAX         0x03

#define BSW_DIR_FORWARD       0x00
#define BSW_DIR_REVERSE       0x01

#define BSW_SPEED_MIN         0x00
#define BSW_SPEED_MAX         0x05

typedef enum
{
    BSW_PARSE_WAIT_HEAD1 = 0,
    BSW_PARSE_WAIT_HEAD2,
    BSW_PARSE_LEN,
    BSW_PARSE_CMD,
    BSW_PARSE_DATA_DIR,
    BSW_PARSE_DATA_SPEED,
    BSW_PARSE_CRC,
    BSW_PARSE_TAIL1,
    BSW_PARSE_TAIL2
} BSW_ParseState_t;

typedef struct
{
    uint8_t cmd;
    uint8_t direction;
    uint8_t speed;
} BSW_MotorCommand_t;

typedef struct
{
    BSW_ParseState_t state;               // ��ǰ����״̬
    BSW_MotorCommand_t command;           // ��ǰ�������ĵ������
    uint8_t frame_buf[BSW_FRAME_SIZE];    // ����֡����
    uint8_t frame_index;                  // ��ǰ����֡����
} BSW_SerProtocol_t;

void BSW_SerProtocol_Init(BSW_SerProtocol_t *protocol);
uint8_t BSW_SerProtocol_InputByte(BSW_SerProtocol_t *protocol, uint8_t data);
uint8_t BSW_SerProtocol_Parse(BSW_SerProtocol_t *protocol, uint8_t *data, uint16_t len);
const BSW_MotorCommand_t * BSW_SerProtocol_GetCommand(BSW_SerProtocol_t *protocol);

#endif
