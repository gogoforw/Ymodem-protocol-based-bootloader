#include "bsw_ser_ring_queue.h"

uint8_t uart_rx_dma_buff[UART_RX_BUFF_LEN];  // DMA Ŀ�껺����
RingQueue g_queue;
static uint16_t last_dma_rx_pos = 0;

void Init_RingQueue(RingQueue *queue)
{
	queue->ring_tail = 0;
	queue->ring_head = 0;
	queue->ring_data_size = 0;
}

void ring_write(RingQueue *queue, uint8_t data)
{
	if(queue->ring_data_size < RING_BUFF_LEN)
	{
		queue->ring_buff[queue->ring_tail] = data;
		queue->ring_tail = (queue->ring_tail + 1) % RING_BUFF_LEN;
		queue->ring_data_size++;
	}
}

uint8_t ring_read(RingQueue *queue)
{
	if(queue->ring_data_size > 0)
	{
		uint8_t tmp = queue->ring_buff[queue->ring_head];
		queue->ring_head = (queue->ring_head + 1) % RING_BUFF_LEN;
		queue->ring_data_size--;
		return tmp;
	}
	else
	{
		return 0xFF;
	}
}

uint16_t getRingSize(RingQueue *queue)
{
	return queue->ring_data_size;
}

void copy_to_ring(RingQueue *queue, uint8_t *src_buff, uint16_t len)
{
	while(len--)
	{
		ring_write(queue, *src_buff++);
	}
}

/**
  * @brief uart1�����жϴ�������.
  */
void uart1_idle_isr(void)
{
	uint16_t recv_total_size;
	uint16_t to_handle_size;
	
	recv_total_size = UART_RX_BUFF_LEN - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);
	to_handle_size = recv_total_size - last_dma_rx_pos;
	copy_to_ring(&g_queue, uart_rx_dma_buff + last_dma_rx_pos, to_handle_size);
	last_dma_rx_pos = recv_total_size;
}

/**
  * @brief DMA�봫���жϴ�������.
  */
void dmarx_half_done_isr(void)
{
	uint16_t recv_total_size;  // DMA �ܽ������ݴ�С
	uint16_t to_handle_size;   // ������Ҫ��������������С
	
	recv_total_size = UART_RX_BUFF_LEN - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);
	to_handle_size = recv_total_size - last_dma_rx_pos;
	copy_to_ring(&g_queue, uart_rx_dma_buff + last_dma_rx_pos, to_handle_size);
	last_dma_rx_pos = recv_total_size;
}

/**
  * @brief DMAȫ�����жϴ�������.
  */
void dmarx_done_isr(void)
{
	uint16_t to_handle_size;
	
	to_handle_size = UART_RX_BUFF_LEN - last_dma_rx_pos;
	copy_to_ring(&g_queue, uart_rx_dma_buff + last_dma_rx_pos, to_handle_size);
	last_dma_rx_pos = 0;
}


