#include "bsw_ser_protocol.h"
#include <string.h>

/*
 * Э��֡��ʽ��
 *  AA 55 LEN CMD DATA CRC 55 AA
 *  ��  ��   ��   ��    ��    ��   ��  ��
 *  ��  ��   ��   ��    ��    ��   ������ ֡β
 *  ��  ��   ��   ��    ��    �������������� CRC = 5A
 *  ��  ��   ��   ��    ������������������������ DATA��2�ֽ�
 *  ��  ��   ��   ���������������������������������� CMD��00~03
 *  ��  ��   ������������������������������������������ LEN = 03
 *  ��  �������������������������������������������������� ֡ͷ
 *  �������������������������������������������������������� ֡ͷ
 */

 /*
    * Э�����״̬����
    *  BSW_PARSE_WAIT_HEAD1: �ȴ�֡ͷ1
    * BSW_PARSE_WAIT_HEAD2: �ȴ�֡ͷ2
    * BSW_PARSE_LEN: �ȴ�����
    * BSW_PARSE_CMD: �ȴ�����
    * BSW_PARSE_DATA_DIR: �ȴ����ݷ���
    * BSW_PARSE_DATA_SPEED: �ȴ������ٶ�
    * BSW_PARSE_CRC: �ȴ�CRC
    * BSW_PARSE_TAIL1: �ȴ�֡β1
    * BSW_PARSE_TAIL2: �ȴ�֡β2
    */

/**
  * @brief This function initializes the protocol parser.
  * @param protocol: Pointer to the protocol parser structure
  * @retval None
  */
void BSW_SerProtocol_Init(BSW_SerProtocol_t *protocol)
{
    if (protocol == NULL)
        return;

    memset(protocol, 0, sizeof(BSW_SerProtocol_t));

    protocol->state = BSW_PARSE_WAIT_HEAD1;
}

/**
  * @brief This function resets the protocol parser to its initial state.
  * @param protocol: Pointer to the protocol parser structure
  * @retval None
  */
static void BSW_SerProtocol_Reset(BSW_SerProtocol_t *protocol)
{
    protocol->state = BSW_PARSE_WAIT_HEAD1;
    protocol->frame_index = 0;
}

/**
  * @brief This function checks if the command is valid.
  * @param cmd: Command to check
  * @retval The ID of the motor if valid, otherwise 0xFF
  */
static uint8_t BSW_SerProtocol_CheckCommand(uint8_t cmd)
{
    return (cmd <= BSW_MOTOR_MAX ? cmd : 0xFF);
}

/**
  * @brief This function checks if the direction is valid.
  * @param direction: Direction to check
  * @retval The direction of the motor if valid, otherwise 0xFF
  */
static uint8_t BSW_SerProtocol_CheckDirection(uint8_t direction)
{
    return ((direction == BSW_DIR_FORWARD || direction == BSW_DIR_REVERSE) ? direction : 0xFF);
}

/**
  * @brief This function checks if the speed is valid.
  * @param speed: Speed to check
  * @retval The speed of the motor if valid, otherwise 0xFF
  */
static uint8_t BSW_SerProtocol_CheckSpeed(uint8_t speed)
{
    return (speed <= BSW_SPEED_MAX ? speed : 0xFF);
}

/**
  * @brief This function processes a single byte of data and updates the protocol parser state.
  * @param protocol: Pointer to the protocol parser structure
  * @param data: Byte of data to process
  * @retval 1 if a complete frame is received, otherwise 0
  */
uint8_t BSW_SerProtocol_InputByte(BSW_SerProtocol_t *protocol, uint8_t data)
{
    if (protocol == NULL)
        return 0;

    switch (protocol->state)
    {
        case BSW_PARSE_WAIT_HEAD1:
            if (data == BSW_FRAME_HEAD1)
            {
                protocol->frame_buf[0] = data;
                protocol->frame_index = 1;
                protocol->state = BSW_PARSE_WAIT_HEAD2;
            }
            break;

        case BSW_PARSE_WAIT_HEAD2:
            if (data == BSW_FRAME_HEAD2)
            {
                protocol->frame_buf[1] = data;
                protocol->frame_index = 2;
                protocol->state = BSW_PARSE_LEN;
            }
            else if (data == BSW_FRAME_HEAD1)
            {
                /*
                 * ��ǰ�ֽ���Ȼ�������µ�֡ͷ
                 */
                protocol->frame_buf[0] = data;
                protocol->frame_index = 1;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_LEN:
            if (data == BSW_FRAME_LEN)
            {
                protocol->frame_buf[2] = data;
                protocol->frame_index = 3;
                protocol->state = BSW_PARSE_CMD;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_CMD:
            if (BSW_SerProtocol_CheckCommand(data) != 0xFF)
            {
                protocol->frame_buf[3] = data;
                protocol->command.cmd = data;
                protocol->frame_index = 4;
                protocol->state = BSW_PARSE_DATA_DIR;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_DATA_DIR:
            if (BSW_SerProtocol_CheckDirection(data) != 0xFF)
            {
                protocol->frame_buf[4] = data;
                protocol->command.direction = data;
                protocol->frame_index = 5;
                protocol->state = BSW_PARSE_DATA_SPEED;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_DATA_SPEED:
            if (BSW_SerProtocol_CheckSpeed(data) != 0xFF)
            {
                protocol->frame_buf[5] = data;
                protocol->command.speed = data;
                protocol->frame_index = 6;
                protocol->state = BSW_PARSE_CRC;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_CRC:
            if (data == BSW_FRAME_CRC)
            {
                protocol->frame_buf[6] = data;
                protocol->frame_index = 7;
                protocol->state = BSW_PARSE_TAIL1;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_TAIL1:
            if (data == BSW_FRAME_TAIL1)
            {
                protocol->frame_buf[7] = data;
                protocol->frame_index = 8;
                protocol->state = BSW_PARSE_TAIL2;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        case BSW_PARSE_TAIL2:
            if (data == BSW_FRAME_TAIL2)
            {
                protocol->frame_buf[8] = data;
                protocol->frame_index = 9;

                /*
                 * һ֡�������ݽ��ճɹ�
                 */
                BSW_SerProtocol_Reset(protocol);

                return 1;
            }
            else
            {
                BSW_SerProtocol_Reset(protocol);
            }
            break;

        default:
            BSW_SerProtocol_Reset(protocol);
            break;
    }
    return 0;
}

/**
  * @brief This function processes a buffer of data and updates the protocol parser state.
  * @param protocol: Pointer to the protocol parser structure
  * @param data: Buffer of data to process
  * @param len: Length of the data buffer
  * @retval 1 if a complete frame is received, otherwise 0
  */
uint8_t BSW_SerProtocol_Parse(BSW_SerProtocol_t *protocol, uint8_t *data, uint16_t len)
{
    uint16_t i;

    if (protocol == NULL || data == NULL)
        return 0;

    for (i = 0; i < len; i++)
    {
        if (BSW_SerProtocol_InputByte(protocol, data[i]))
        {
            return 1;
        }
    }
    return 0;
}

const BSW_MotorCommand_t *BSW_SerProtocol_GetCommand(BSW_SerProtocol_t *protocol)
{
    if (protocol == NULL)
        return NULL;

    return &protocol->command;
}



