#ifndef __YMODEM_CRC_H
#define __YMODEM_CRC_H

#include <stdio.h>
#include <stdint.h>

uint16_t UpdateCRC16(uint16_t crc_in, uint8_t byte);
uint16_t Cal_CRC16(const uint8_t* p_data, uint32_t size);
uint8_t CalcChecksum(const uint8_t *p_data, uint32_t size);
uint16_t Ymodem_CRC16(const uint8_t *data, uint16_t length);

#endif  /* __YMODEM_CRC_H_ */

/*******************(C)COPYRIGHT STMicroelectronics ********END OF FILE********/
