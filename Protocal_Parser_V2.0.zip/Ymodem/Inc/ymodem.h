#ifndef __YMODEM_H
#define __YMODEM_H

#include <stdint.h>
#include "ymodem_port.h"
#include "ymodem_flash.h"

/* YMODEM ���պͷ��ͺ������� */
void Ymodem_ReceiveInit(void);
Ymodem_Result_t Ymodem_Receive(void);
static void Ymodem_HandleWaitHeader(Ymodem_Context_t *ctx, RingQueue *queue);
static void Ymodem_HandleWaitData(Ymodem_Context_t *ctx, RingQueue *queue);
static void Ymodem_HandleWaitEot(Ymodem_Context_t *ctx, RingQueue *queue);
static void Ymodem_HandleWaitEotSecond(Ymodem_Context_t *ctx, RingQueue *queue);
static void Ymodem_HandleWaitEndPacket(Ymodem_Context_t *ctx, RingQueue *queue);

// void Ymodem_TransmitInit(const char *filename,
//                          uint32_t file_size,
//                          uint32_t file_start_addr);

// Ymodem_Result_t Ymodem_Transmit(void);

#endif  /* __YMODEM_H_ */
/*******************(C)COPYRIGHT STMicroelectronics ********END OF FILE********/

