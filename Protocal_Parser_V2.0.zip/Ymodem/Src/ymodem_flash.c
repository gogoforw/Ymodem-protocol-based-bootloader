/**
  ******************************************************************************
  * @file    Ymodem/Src/ymodem_flash.c 
  * @author  MCD Application Team
  * @version 1.0.0
  * @date    1-Nov-2026
  * @brief   This file provides all the memory related operation functions.
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "ymodem_flash.h"
#include <string.h>

static const uint32_t FlashSectorAddress[12] = {
    ADDR_FLASH_SECTOR_0,
    ADDR_FLASH_SECTOR_1,
    ADDR_FLASH_SECTOR_2,
    ADDR_FLASH_SECTOR_3,
    ADDR_FLASH_SECTOR_4,
    ADDR_FLASH_SECTOR_5,
    ADDR_FLASH_SECTOR_6,
    ADDR_FLASH_SECTOR_7,
    ADDR_FLASH_SECTOR_8,
    ADDR_FLASH_SECTOR_9,
    ADDR_FLASH_SECTOR_1O,
    ADDR_FLASH_SECTOR_11
};
/* Private function prototypes -----------------------------------------------*/

/**
  * @brief  Get the sector number of a given address
  * @param  address: The address to get the sector number
  * @retval 0~11: Sector number, -1: Address is out of range
  */
static int8_t FLASH_If_GetSector(uint32_t address)
{
    uint8_t i;

    for (i = 0; i < 12U; i++)
    {
        if (FlashSectorAddress[i] == address)
        {
            return (int8_t)i;
        }
    }

    return -1;
}

/**
  * @brief  Unlocks Flash for write access
  * @param  None
  * @retval None
  */
void FLASH_If_Init(void)
{
  /* Unlock the Program memory */
  HAL_FLASH_Unlock();

  /* Clear all FLASH flags */
  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_WRPERR | FLASH_FLAG_OPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);
  /* Unlock the Program memory */
  HAL_FLASH_Lock();
}

uint32_t FLASH_If_Get_NbrOfSectors(uint32_t file_size)
{
  if((file_size == 0) || (file_size > APP_SIZE))
  {
    return 0;
  }
  
  if(file_size <= 0x10000U)  // ����4 (64 KB)
  {
    return 1;
  }
  else if(file_size <= 0x30000U)  // ����4~5 (64 + 128 KB)
  {
    return 2;
  }
  else if(file_size <= 0x50000U)  // ����4~6 (64 + 128*2 KB)
  {
    return 3;
  }
  else if(file_size <= 0x70000U)  // ����4~7 (64 + 128*3 KB)
  {
    return 4;
  }
  else if(file_size <= 0x90000U)  // ����4~8 (64 + 128*4 KB)
  {
    return 5;
  }
  else if(file_size <= 0xB0000U)  // ����4~9 (64 + 128*5 KB)
  {
    return 6;
  }
  else if(file_size <= 0xD0000U)  // ����4~10 (64 + 128*6 KB)
  {
    return 7;
  }
  else if(file_size <= 0xF0000U)  // ����4~11 (64 + 128*7 KB)
  {
    return 8;
  } 
  else
  {
    return 0;
  }
}

uint32_t FLASH_If_Erase_Need(uint32_t start, uint32_t NbrOfSectors)
{
  int8_t   Res;
  uint32_t SectorError = 0;
  FLASH_EraseInitTypeDef pEraseInit = {0};
  HAL_StatusTypeDef status;

  /* Unlock the Flash to enable the flash control register access *************/
  Res = FLASH_If_GetSector(start);
  if(Res < 0)
  {
    return FLASHIF_ERASEKO;   
  }

  HAL_FLASH_Unlock();

  /* Fill EraseInit structure*/
  pEraseInit.TypeErase = FLASH_TYPEERASE_SECTORS;   // Sector Erase
  pEraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;  // 3.3V
  pEraseInit.Sector = (uint32_t)Res;                // APP start sector
  pEraseInit.NbSectors = NbrOfSectors;              // Number of sectors to erase
  status = HAL_FLASHEx_Erase(&pEraseInit, &SectorError);

  /* Lock the Flash to disable the flash control register access (recommended
     to protect the FLASH memory against possible unwanted operation) *********/
  HAL_FLASH_Lock();

  if (status != HAL_OK)
  {
    /* Error occurred while sector erase */
    return FLASHIF_ERASEKO;
  }

  return FLASHIF_OK;
}

/**
  * @brief  This function does an erase of all user flash area
  * @param  start: start of user flash area
  * @retval FLASHIF_OK : user flash area successfully erased
  *         FLASHIF_ERASEKO : error occurred
  */
uint32_t FLASH_If_Erase(uint32_t start)
{
  int8_t   Res;
  uint32_t NbrOfSectors; 
  uint32_t SectorError = 0;
  FLASH_EraseInitTypeDef pEraseInit = {0};
  HAL_StatusTypeDef status;

  /* Unlock the Flash to enable the flash control register access *************/
  Res = FLASH_If_GetSector(start);
  if(Res < 0)
  {
    return FLASHIF_ERASEKO;   
  }

  NbrOfSectors = FLASH_SECTOR_COUNT - (uint32_t)Res;  // Number of sectors to erase from start sector to the end of flash (APP area)
  HAL_FLASH_Unlock();

  /* Fill EraseInit structure*/
  pEraseInit.TypeErase = FLASH_TYPEERASE_SECTORS;   // Sector Erase
  pEraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;  // 3.3V
  pEraseInit.Sector = (uint32_t)Res;                // APP start sector
  pEraseInit.NbSectors = NbrOfSectors;              // Number of sectors to erase
  status = HAL_FLASHEx_Erase(&pEraseInit, &SectorError);

  /* Lock the Flash to disable the flash control register access (recommended
     to protect the FLASH memory against possible unwanted operation) *********/
  HAL_FLASH_Lock();

  if (status != HAL_OK)
  {
    /* Error occurred while sector erase */
    return FLASHIF_ERASEKO;
  }

  return FLASHIF_OK;
}

/* Public functions ---------------------------------------------------------*/
/**
  * @brief  This function writes a data buffer in flash (data are 32-bit aligned).
  * @note   After writing data buffer, the flash content is checked.
  * @param  destination: start address for target location
  * @param  p_source: pointer on buffer with data to write
  * @param  length: length of data buffer (unit is byte)
  * @retval uint32_t 0: Data successfully written to Flash memory
  *         2: Written Data in flash memory is different from expected one
  *         3: Error occurred while writing data in Flash memory
  */
uint32_t FLASH_If_Write(uint32_t destination, const uint8_t *p_source, uint32_t length)
{
  uint32_t i = 0;
  uint32_t data;
  uint32_t write_size;

  /* 1. Դ����ָ�벻��Ϊ�գ�д�볤�Ȳ���Ϊ0 */
  if((p_source == NULL) || (length == 0U))
  {
    return FLASHIF_WRITING_ERROR;
  }

  /* 2. ���FlashĿ���ַ�Ƿ�����32λ�ֶ���Ҫ�� */
  if ((destination & 0x03U) != 0U)
  {
    return FLASHIF_WRITING_ERROR;
  }

  /* 3. ���Ŀ���ַ��д�볤���Ƿ񳬳�APP ���� */
  if((destination < APPLICATION_ADDRESS) || (destination >= USER_FLASH_END_ADDRESS) || (length > (USER_FLASH_END_ADDRESS - destination)))
  {
    return FLASHIF_WRITING_ERROR;
  }

  /* 4. Unlock the Flash to enable the flash control register access *************/
  HAL_FLASH_Unlock();

  /* 5. ����32λ��Ϊ��λѭ��д������ */
  for (i = 0; i < length; i += 4U)
  {
    data = 0xFFFFFFFFU;       // Ĭ�����0xFF
    write_size = length - i;  // ���㵱ǰ��д������ݳ���

    if(write_size >= 4U)
    {
      data = *(uint32_t *)(p_source + i);       // ȡ��4�ֽ�����
    }
    else
    {
      memcpy(&data, p_source + i, write_size);  // ���ʣ�����ݲ���4�ֽڣ�����Ҫ�������
    }

    /* 6. ������д��Flash */
    /* Device voltage range supposed to be [2.7V to 3.6V], the operation will
       be done by word */ 
    if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, destination, data) != HAL_OK)      
    {
      HAL_FLASH_Lock();
      return FLASHIF_WRITING_ERROR;
    }
    
    /* 7. �ض�Flash���ݣ���֤ʵ��д���� */
    if(*( volatile uint32_t *)destination != data)
    {
      HAL_FLASH_Lock();
      return FLASHIF_WRITINGCTRL_ERROR;
    }
    /* 8. ����Flash Ŀ���ַ��׼��д����һ��32λ�� */
    destination += 4U;
  }

  /* Lock the Flash to disable the flash control register access (recommended
     to protect the FLASH memory against possible unwanted operation) *********/
  HAL_FLASH_Lock();

  return FLASHIF_OK;
}

/**
  * @brief Checks if the application at the specified address is ready to run.
  * @param app_addr: The starting address of the application in Flash memory.
  * @retval 1 if the application is ready, 0 otherwise.
  */
uint8_t App_IsReady(uint32_t app_addr)
{
  uint32_t app_sp = *(volatile uint32_t *)app_addr;
  uint32_t app_pc = *(volatile uint32_t *)(app_addr + 4U);

  // ���ջָ��ͳ���������Ƿ�����Ч��Χ��
  if((app_sp < APP_STACK_START) || (app_sp > APP_STACK_END))
  {
    //printf("Stack pointer is out of range: 0x%08lX\r\n", (uint32_t)app_sp);
    return 0; // Stack pointer is out of range
  }
  if((app_pc < APP_ADDR) || (app_pc > (APP_ADDR + APP_SIZE)))
  {
    //printf("Program counter is out of range: 0x%08lX\r\n", (uint32_t)app_pc);
    return 0; // Program counter is out of range
  }
	if((app_pc & 0x1U) == 0U)
	{
		return 0;
	}
  return 1; // Application is ready
}

void App_JumpTo(uint32_t app_addr)
{
  // ��ȡӦ�ó����ջָ��ͳ��������
  uint32_t app_sp = *(volatile uint32_t *)app_addr;
  uint32_t app_pc = *(volatile uint32_t *)(app_addr + 4U);

  __disable_irq(); // �����ж�

  SysTick->CTRL = 0; // ���� SysTick ��ʱ��
  SysTick->LOAD = 0; // ��� SysTick ������
  SysTick->VAL = 0;  // ��� SysTick ��ǰֵ

  SCB->VTOR = app_addr; // ����������ƫ�ƼĴ���ΪӦ�ó������ʼ��ַ
  __DSB();
  __ISB();

  // ������ջָ��
  __set_MSP(app_sp);
  __enable_irq();       // �ؼ�
  // ���庯��ָ������
  typedef void (*AppEntryFunc)(void);
  AppEntryFunc app_entry = (AppEntryFunc)app_pc;

  // ��ת��Ӧ�ó�����ڵ�
  app_entry();
  while(1)
  {
    // ���Ӧ�ó��򷵻أ�������ѭ��
  }
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
